﻿package com.grand.admin.keyboard;

import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;

public class AdminKeyboardService extends InputMethodService implements KeyboardView.OnKeyboardActionListener {

    private KeyboardView keyboardView;
    private Keyboard currentKeyboard;
    
    // Счётчики репортов для статистики
    private int reportCount = 0;
    private int formCount = 0;

    @Override
    public View onCreateInputView() {
        keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        currentKeyboard = new Keyboard(this, R.xml.admin_placement);
        keyboardView.setKeyboard(currentKeyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

        switch (primaryCode) {
            case -5: // Backspace (Стереть)
                ic.deleteSurroundingText(1, 0);
                break;
            case 32: // Пробел
                ic.commitText(" ", 1);
                break;

            // Вкладка АДМИН -> НАКАЗАНИЯ
            case 201: // /jail
                ic.commitText("/jail ", 1);
                break;
            case 202: // /mute
                ic.commitText("/mute ", 1);
                break;
            case 203: // /kick
                ic.commitText("/kick ", 1);
                break;
            case 204: // /ban
                ic.commitText("/ban ", 1);
                break;

            // Вкладка АДМИН -> ЧАТЫ (Команды для себя)
            case 301: // Маска
                ic.commitText("/clist", 1);
                break;
            case 302: // ID машины
                ic.commitText("/dl", 1);
                break;
            case 303: // Выдать себе здоровье
                ic.commitText("/hp 100", 1);
                break;

            // Вкладка АДМИН -> СПАВН
            case 401: // Админ зона
                ic.commitText("/az", 1);
                break;
            case 402: // Спавн
                ic.commitText("/spawn", 1);
                break;

            // Вкладка ОТВЕТЫ (Репорт)
            case 501: // Слежу
                ic.commitText("/ans  Приветствую! Начинаю слежку за игроком. С уважением, ATOOLS.", 1);
                reportCount++;
                break;
            case 502: // Не оффтопьте
                ic.commitText("/ans  Приветствую! Уважаемый игрок, не оффтопте в репорт.", 1);
                reportCount++;
                break;

            // Вкладка ФОРМЫ (Автоприем из буфера)
            case 601: 
                if (clipboard != null && clipboard.hasPrimaryClip()) {
                    ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                    String textFromChat = item.getText().toString().strip();
                    
                    if (textFromChat.contains("/jail") || textFromChat.contains("/mute") || textFromChat.contains("/kick") || textFromChat.contains("/ban")) {
                        String approvedCmd = textFromChat.startsWith("/") ? "/ap" + textFromChat.substring(1) : "/ap" + textFromChat;
                        ic.commitText(approvedCmd, 1);
                        formCount++;
                    }
                }
                break;

            // Вкладка СТАТА (Счетчик репортов)
            case 701:
                ic.commitText("ATOOLS | Статистика за смену: Репортов: " + reportCount + " | Форм: " + formCount, 1);
                break;

            default:
                char code = (char) primaryCode;
                ic.commitText(String.valueOf(code), 1);
        }
    }

    @Override public void onPress(int primaryCode) {}
    @Override public void onRelease(int primaryCode) {}
    @Override public void onText(CharSequence text) {}
    @Override public void swipeLeft() {}
    @Override public void swipeRight() {}
    @Override public void swipeDown() {}
    @Override public void swipeUp() {}
}

